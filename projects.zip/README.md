Modules
    *Shop
      - Produits
      - Liste de toutes les commandes
      - Liste des commandes de l'utilisateur connecté
      - Fomulaire de validation du panier

    *Pages simples
      - Accueil
      - Contactez-nous
      - Page non trouvée