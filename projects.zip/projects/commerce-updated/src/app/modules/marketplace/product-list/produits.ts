export const Produits = [
  {
    nom: 'Caméra',
    description:
      'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    prix: 12.99,
    picture: '../../../assets/images/produits/2.jpg',
  },
  {
    nom: 'Ecran 25 pouces',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    prix: 10.99,
    picture: '../../../assets/images/produits/1.jpg',
  },
  {
    nom: 'Manette',
    description:
      'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
    prix: 15.99,
    picture: '../../../assets/images/produits/3.jpg',
  },
  {
    nom: 'Ecran 16 pouces',
    description:
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
    prix: 12,
    picture: '../../../assets/images/produits/4.jpg',
  },
  {
    nom: 'Bocal',
    description:
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
    prix: 9,
    picture: '../../../assets/images/produits/5.jpg',
  },
  {
    nom: 'Casque',
    description:
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
    prix: 15,
    picture: '../../../assets/images/produits/6.jpg',
  },
  {
    nom: 'Micro',
    description:
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
    prix: 16.45,
    picture: '../../../assets/images/produits/7.jpg',
  },
  {
    nom: 'HUAWEI',
    description:
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
    prix: 110,
    picture: '../../../assets/images/produits/8.jpg',
  }, 
  {
    nom: 'IPHONE ',
    description:
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
    prix: 120.34,
    picture: '../../../assets/images/produits/9.jpg',
  },
  {
    nom: 'SAMSUNG',
    description:
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
    prix: 130,
    picture: '../../../assets/images/produits/10.jpg',
  },
  {
    nom: 'Montre',
    description:
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
    prix: 20,
    picture: '../../../assets/images/produits/11.jpg',
  },
  {
    nom: 'SAMSUNG S9',
    description:
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
    prix: 135,
    picture: '../../../assets/images/produits/12.jpg',
  },
  {
    nom: 'Pack informatique',
    description:
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
    prix: 200,
    picture: '../../../assets/images/produits/13.jpg',
  },
];
