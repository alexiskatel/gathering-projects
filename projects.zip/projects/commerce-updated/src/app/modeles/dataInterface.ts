import { Product } from "./productInterface";

export interface DataInterface{
  produits: Product[],
  price: number
}