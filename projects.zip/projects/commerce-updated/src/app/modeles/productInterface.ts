export interface Product {
  nom: string,
  quantite: number,
  prix: number,
  picture: string,
}